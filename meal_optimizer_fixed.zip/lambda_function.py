import json
import os
import polars as pl
import boto3
from io import StringIO

def create_optimal_meals(event, context):
    """
    Version simplifiée sans numpy/scipy - utilise seulement des calculs basiques
    """
    try:
        print(f"Event reçu: {json.dumps(event)}")
        
        # Configuration S3
        bucket_name = os.environ.get('S3_BUCKET_NAME')
        file_key = os.environ.get('CSV_FILE_KEY')
        
        print(f"S3 Bucket: {bucket_name}, Key: {file_key}")
        
        if not bucket_name or not file_key:
            return {
                'statusCode': 500,
                'body': json.dumps({'error': 'S3 configuration missing from environment variables'})
            }
        
        # Paramètres de l'événement
        user_data = event.get('user')
        meal_fraction = event.get('meal_fraction', 0.3)
        sample_size = event.get('sample_size', 100)
        
        if not user_data or 'target_array' not in user_data:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Missing user data with target_array'})
            }
        
        # Chargement depuis S3
        try:
            s3_client = boto3.client('s3')
            print(f"Tentative de lecture S3: {bucket_name}/{file_key}")
            response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
            csv_content = response['Body'].read().decode('utf-8')
            print(f"CSV lu, taille: {len(csv_content)} caractères")
            
            # Lecture CSV simple avec gestion d'erreurs
            products_df = pl.read_csv(StringIO(csv_content), ignore_errors=True)
            print(f"DataFrame créé avec {len(products_df)} lignes")
            
        except Exception as s3_error:
            print(f"Erreur S3: {str(s3_error)}")
            return {
                'statusCode': 500,
                'body': json.dumps({'error': f'Failed to read from S3: {str(s3_error)}'})
            }
        
        # Échantillonnage si nécessaire
        if len(products_df) > sample_size:
            products_df = products_df.sample(sample_size)
            print(f"Échantillon réduit à {len(products_df)} produits")
        
        # Calcul simple des cibles
        user_targets = user_data['target_array']
        targets = {
            'calories': user_targets[0] * meal_fraction,
            'protein_cal': user_targets[1] * meal_fraction,
            'fat_g': user_targets[2] * meal_fraction,
            'carbs_g': user_targets[3] * meal_fraction
        }
        
        print(f"Cibles calculées: {targets}")
        
        # Sélection simple des meilleurs produits (algorithme basique)
        meal_plan = []
        
        if len(products_df) > 0:
            # Prenez les premiers produits et calculez des portions basiques
            selected_products = products_df.head(min(5, len(products_df)))
            
            for i, row in enumerate(selected_products.iter_rows(named=True)):
                # Portion basique proportionnelle aux besoins
                base_portion = 50 + (i * 25)  # 50g, 75g, 100g, etc.
                
                meal_plan.append({
                    'product_name': row.get('product_name', f'Product_{i}'),
                    'quantity_g': base_portion
                })
        
        response_data = {
            "meal_plan": meal_plan,
            "targets": targets,
            "note": "Version simplifiée sans optimisation scipy - sélection basique",
            "products_available": len(products_df),
            "products_in_plan": len(meal_plan)
        }
        
        print(f"Réponse générée: {len(meal_plan)} produits")
        
        return {
            'statusCode': 200,
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        print(f"Erreur générale: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
